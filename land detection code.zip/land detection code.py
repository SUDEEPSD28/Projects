import cv2
import numpy as np

cap = cv2.VideoCapture(0)

lower_green = np.array([40, 50, 50])
upper_green = np.array([80, 255, 255])

matrix_rows = 25
matrix_cols = 25
result_matrix = np.zeros((matrix_rows, matrix_cols), dtype=int)

interval = 5

while True:
    # wait for specified interval
    for i in range(interval):
        ret, frame = cap.read()
        cv2.imshow('frame', frame)
        cv2.waitKey(1000)  # wait 1 second

    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

    mask = cv2.inRange(hsv, lower_green, upper_green)

    cell_width = int(frame.shape[1] / matrix_cols)
    cell_height = int(frame.shape[0] / matrix_rows)
    for i in range(matrix_rows):
        for j in range(matrix_cols):
            x = j * cell_width
            y = i * cell_height
            cell_mask = mask[y:y + cell_height, x:x + cell_width]
            if np.sum(cell_mask) > 0:
                result_matrix[i][j] = 1
            else:
                result_matrix[i][j] = 0

    print(result_matrix)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()